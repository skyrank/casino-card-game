# Casino Card Game

A multiplayer implementation of the classic Casino card game built with React and Firebase.

## Features

- Two-player gameplay
- Real-time multiplayer with Firebase
- Card capturing mechanics (pairing, combining, building)
- Proper scoring system
- Mobile-friendly interface

## How to Play

Casino is a traditional card game where players capture cards from the table by:
- **Pairing**: Match a card from your hand with a card of the same rank on the table
- **Combining**: Use a card from your hand to capture multiple cards that sum to its value
- **Building**: Create builds of cards that sum to a target value for later capture

## Scoring

- **Aces**: 1 point each
- **Big Casino** (10 of Diamonds): 2 points
- **Little Casino** (2 of Spades): 1 point
- **Most Spades**: 1 point
- **Most Cards**: 3 points

## Development

```bash
npm install
npm start
```

## Deployment

```bash
npm run deploy
```

Deploys to GitHub Pages at: https://josephomansky.github.io/casino-card-game
